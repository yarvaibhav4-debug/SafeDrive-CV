# SafeDrive CV

**Detection of Traffic Signals and Lane Markings for Safe Driving Cars Using Computer Vision**

A third-year CSE academic prototype. It accepts a road video through a simple Flask website, performs OpenCV-based lane detection, estimates lane status, performs lightweight traffic-light colour analysis, and displays a safety status on the processed video.

## Important scope

This is a driver-assistance prototype. It does **not** control steering, brakes or acceleration and must not be used as a real vehicle safety system.

## Run locally

### 1. Install Python 3.10+.

### 2. Open a terminal in this folder

### 3. Create a virtual environment

Windows:
```bash
python -m venv venv
venv\Scripts\activate
```

macOS/Linux:
```bash
python3 -m venv venv
source venv/bin/activate
```

### 4. Install dependencies

```bash
pip install -r requirements.txt
```

### 5. Start the website

```bash
python app.py
```

### 6. Open the local website

Go to:

`http://127.0.0.1:5000`

Upload a road video and click **Analyse Video**.

## Current implementation

- Flask web interface
- Road-video upload
- OpenCV grayscale/blur/Canny/Hough lane pipeline
- Lane-centre estimation
- Lane status
- Lightweight red/yellow/green colour analysis
- Rule-based STOP / CAUTION / GO / LANE DEPARTURE WARNING
- Annotated output video

## Planned upgrade

For the next iteration, integrate a pre-trained YOLO traffic-light detector in `traffic_detection.py`. YOLO should locate the traffic-light object first; colour analysis can then be applied only inside the detected bounding box. This is more reliable than searching the whole frame for colours.

## Suggested demo video

Use a forward-facing road video with:
- clearly visible lane markings
- at least one traffic light
- daylight conditions
- 20–60 seconds duration

## Troubleshooting

### `python` is not recognized
Install Python and enable "Add Python to PATH".

### `No module named cv2`
Run:
```bash
pip install -r requirements.txt
```

### Video does not play in browser
The prototype writes MP4 using a broadly available OpenCV codec. If a browser has codec issues, download/open the processed file with a local media player or convert it with FFmpeg.

## Project flow

Road Video → Frame Processing → Lane Detection + Traffic Signal Analysis → Safety Logic → Annotated Video
